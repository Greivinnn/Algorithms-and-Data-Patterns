#pragma once

enum class Stats
{
	Health,		// 0
	Attack,		// 1
	Defense,	// 2
	Stamina,	// 3
	Speed,		// 4
	Count		// 5
};